from nltk.corpus import stopwords
import nltk
import string
import json

# Download NLTK data if not already available for tokenization and stop words
try:
    nltk.download('all')
    print("Downloaded")
except:
    print("Error in downloading NLTK")
stop_words = stopwords.words('english')
punctuation = set(string.punctuation)
lemmatizer = nltk.stem.wordnet.WordNetLemmatizer()
word_threshold = 5
processed_word_threshold = 3

def processComment(comment):
    if len(comment) < word_threshold:
        return ""

    try:
        tokens = nltk.tokenize.word_tokenize(comment)
        filtered_tokens = []
        # Remove punctuation and stopwords
        for token in tokens:
            token = token.lower()
            if token in stop_words or token in punctuation or len(list(set(token).intersection(punctuation))) > 0:
                continue
            filtered_tokens.append(token)

        sentence = ' '.join(filtered_tokens)

        # Get POS tagging for the sentence and lemmatize nouns and verbs, other POS are added without any processing
        pos_tree = nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sentence))).leaves()
        sentence_words = []
        for leaf in pos_tree:
            if 'NN' in leaf[1] or 'NP' in leaf[1]:
                lemma = lemmatizer.lemmatize(leaf[0])
                sentence_words.append(lemma)
            elif 'VB' in leaf[1]:
                lemma = lemmatizer.lemmatize(leaf[0], 'v')
                sentence_words.append(lemma)
            else:
                sentence_words.append(leaf[0])

        if len(sentence_words) > processed_word_threshold:
            return ' '.join(sentence_words)
        else:
            return ""
    except Exception as e:
        return ""

comments = []
ratings = []
user_ids = []
original = []

users = []

f = open("user.json")
for line in f:
    j = json.loads(line)
    year = int(j['yelping_since'].split('-')[0])
    if year == 2016:
        users.append(j['user_id'])
f.close()

print("List created")

f = open("review.json")
count = 0
for line in f:
    j = json.loads(line)
    if j['user_id'] not in users:
        continue
    comment = j['text'].encode('utf8', errors='ignore').rstrip("\n")
    processedComment = processComment(comment)
    if len(processedComment) == 0:
        continue

    user_ids.append(j['user_id'])
    comments.append(processedComment)
    original.append(comment)
    ratings.append(str(j['stars']))
    count = count + 1
f.close()

f4 = open("processedData.txt", "w")
for i in range(len(user_ids)):
    try:
        f4.write(user_ids[i] + "\t" + original[i].encode('utf8', errors='ignore') + "\t" + comments[i].encode('utf8', errors='ignore') + "\t" + ratings[i] + "\n")
    except:
        continue