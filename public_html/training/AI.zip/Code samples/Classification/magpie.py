from magpie import Magpie
magpie = Magpie()
magpie.init_word_vectors('files', vec_dim=100)
labels = ['1', '2', '3', '4', '5']
magpie.save_word2vec_model('models/embeddings')
magpie.save_scaler('models/scaler', overwrite=True)
# The next time you want to run this program, you wouldn't have to get the word embeddings again, and can simply use the following commented line
# magpie = Magpie(word2vec_model='models/embeddings', scaler='models/scalar')

magpie.batch_train('files', labels, epochs=1)
magpie.save_model('models/sentiment.h5')

# Here are different ways to get predictions
# magpie.predict_from_file('data/hep-categories/1002413.txt')
# magpie.predict_from_text('Stephen Hawking studies black holes')

