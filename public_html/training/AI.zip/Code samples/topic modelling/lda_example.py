from nltk.corpus import stopwords
import nltk
import string
from gensim import corpora
from gensim.models.wrappers import LdaMallet
import json

"""
Runs LDA on the data and identifies topic keywords
"""


def run_lda(processed_sentences):
    number_of_topics=20
    number_of_lda_keywords=10
    number_of_lda_keywords_processed=20
    number_of_lda_keywords_for_assignment=500
    lemmatizer = nltk.stem.wordnet.WordNetLemmatizer()
    # List containing the final topic keywords
    topic_top_words = []

    documents = [comment.split() for comment in processed_sentences if comment]
    dictionary = corpora.Dictionary(documents)
    # Filter the words that occur in less than 5 comments or those that occur in more than half of the comments
    dictionary.filter_extremes(no_below=5, no_above=0.5)
    doc_term_matrix = [dictionary.doc2bow(doc) for doc in documents]
    mallet_path = 'C:\\mallet\\bin\\mallet' 
    optimization_interval = 50
    lda_alpha = 1

    lda = LdaMallet(mallet_path, doc_term_matrix, num_topics=number_of_topics, id2word=dictionary, optimize_interval=optimization_interval, alpha=lda_alpha)

    # This list contains the word probabilities given a topic
    topic_words_and_probs = []

    for i in range(number_of_topics):
        # Get top number_of_lda_keywords_for_assignment words and corresponding probabilities for the topic
        topic_words_and_probs.append(lda.show_topic(i, topn=number_of_lda_keywords_for_assignment))

        # Get the top keywords for the topic and extract the top nouns
        topic_words = [component[0] for component in lda.show_topic(i, topn=number_of_lda_keywords_processed)]

        final_topic_words = []

        for word in topic_words:
            word = word.encode('ascii', 'ignore')
            if len(final_topic_words) >= number_of_lda_keywords:
                break

            pos = nltk.pos_tag([word])
            word = lemmatizer.lemmatize(word)
            noun_tags = ['NN', 'NNS', 'NP', 'NPS']
            if word not in final_topic_words and pos[0][1] in noun_tags:
                final_topic_words.append(word)
        topic_top_words.append(final_topic_words)
    return topic_top_words, topic_words_and_probs


"""
Uses the topic keywords to determine topic distribution. Also processes the LDA and classification output to return the result as a json
"""


def process_result(processed_sentences, topic_words_and_probs, topic_top_words):
    text=[]
    number_of_topics=20
    # List containing the final result objects
    out = []
    # Find the most appropriate topic for a comment by combining the topic-word probabilities and normalizing them
    for idx, comment in enumerate(processed_sentences):
        if comment:
            max_probability = 0
            best_topics = []
            words = comment.split(' ')
            for j in range(number_of_topics):
                probability = sum([component[1] for component in topic_words_and_probs[j] if component[0] in words]) / float(len(words))
                if probability > max_probability:
                    best_topics = [j]
                    max_probability = probability
                elif probability == max_probability and probability > 0:
                    best_topics.append(j)

            for topic in best_topics:
                out.append({
                    'comment': text[idx],
                    'topic': topic_top_words[topic]
                })
            if len(best_topics) == 0:
                out.append({
                    'comment': text[idx],
                    'topic': ['Other']
                })

        else:
            out.append({
                'comment': text[idx],
                'topic': [None],
            })

    return out


def get_topics():
    processed_sentences = []
    f = open("ldaData.txt")
    for line in f:
        if len(line.split("\t")) <= 1:
            continue
        processed_sentences.append(line.split("\t")[1].rstrip("\n"))
    f.close()
    print(len(processed_sentences))
    topic_top_words, topic_words_and_probs = run_lda(processed_sentences=processed_sentences)
    out = process_result(processed_sentences=processed_sentences, topic_top_words=topic_top_words, topic_words_and_probs=topic_words_and_probs)
    with open('out.txt', 'w') as outfile:
        json.dump(out, outfile)
    return out

get_topics()